package main

import "github.com/cod3rcursos/goarea"
import "fmt"

func main() {
	fmt.Println(goarea.Circ(4.0))
}
