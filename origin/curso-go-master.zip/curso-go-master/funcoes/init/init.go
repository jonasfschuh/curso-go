package main

import "fmt"

func init() {
	fmt.Println("Inicializando...")
}

func main() {
	fmt.Println("Main...")
}
