package main

import "fmt"

func init() {
	fmt.Println("Inicializando2...")
}
