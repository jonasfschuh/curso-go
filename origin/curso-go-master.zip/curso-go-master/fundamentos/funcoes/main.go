package main

func main() {
	resultado := somar(3, 4)
	imprimir(resultado)
}
